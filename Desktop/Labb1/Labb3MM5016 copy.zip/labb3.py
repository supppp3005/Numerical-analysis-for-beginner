#!/ usr / bin / python3

import numpy as np
import matplotlib.pyplot as plt
import scipy.interpolate as interpolate
import math


# Part 1: Interpolation
# 2. Interpolation of temperature measurements

# In order to plot 
# I changed the file name of temperature data file to labb333.csv
# 2.1
tempdata = np.genfromtxt('labb333.csv', delimiter =',')
year = tempdata [1:len ( tempdata ) ,0]
meantemperature = tempdata [1:len ( tempdata ) ,-1]
startindex =259 # 2015
x= year [ startindex :-1]
y= meantemperature [ startindex :-1]



# x for plotting
xnew =np.linspace (2015 ,2019 , 100 )

# 2.2 linear interpolation
f= interpolate.interp1d(x , y , kind = 'linear')



# 2.3 Lagrange polynomial 
p=interpolate.lagrange(x,y)


# gives  Lagrange polynomial
# print(p)


# 2.5 cubic splines
f2= interpolate.interp1d(x , y , kind = 'cubic')


plt.plot(x ,y ,'*', label ='Data')
plt.plot ( xnew , f(xnew) , label ='Linear ')
plt.plot(xnew, p(xnew), label ='Polynomial')
plt.plot(xnew, f2(xnew), label ='Cubic Spline')
plt.legend ()
plt.title("Plot for temperature data points between 2015-20.")
plt.savefig('labb3 plot 1')
plt.show()



# Part 2 :Basic ODEs and differentiation

# 2.1 Numerical Differentiation of the Stockholm Temperature Data
# By using forward difference formula in cubic spine (2015-2019)

dT=[]
for i in range(len(xnew)):
    if i == len(xnew)-1:
        dT.append(float("NaN"))
        break
    else:
       d=(f2(xnew[i+1])-f2(xnew[i]))
       t=(xnew[i+1]-xnew[i])
       dT.append(d/t)
       
# dT/dt for data points(2015-2019)
dT1=[0.0]*len(x)
for i in range(len(y)-1):
    dT1[i]=(y[i+1]-y[i])/(x[i+1]-x[i])
# for the last data point 
dT1[-1]=float("NaN")


# plotting dT/dt
plt.figure(2)
plt.plot(x,y,'*', label = 'Data')
plt.plot(x,dT1, label ='Forward derivative dT/dt for data')
plt.plot(xnew ,f2(xnew), label ='Cubic spine')
plt.plot(xnew,dT,label='Forward-derivative dT/dt for cubic spine')
plt.legend()
plt.title(" Plot for dT/dt between 2015-20")
plt.show



# 2. 2 the average of the derivative .
# deletes the last point (NaN)
dT2= np.delete(dT,-1)
average_derivative = np.average(dT2)
# in order to print change startindex to 1 and xnew=(1757,....)
# print(average_derivative)





# 3. Numerical Differentiation of the sinusoidal


# x for plotting
xsin =np.linspace (0 ,1 , 100 )


# exact function
ysin =np.sin( 2* math .pi* xsin )


# 3.1  Derivative of function
df= 2*math.pi*np.cos( 2* math .pi* xsin )


# 3.2   By forward difference method 
def Df(f,x,h) :
    return (f(x + h) - f(x))/h

# x- coords for interpolation points
# N =10
xcoarse =np.linspace (0 ,1 ,10)

# the function we are derivating
fx = lambda x: np.sin(2*math.pi* x)

# h=1/N=1/10
d1 = Df(fx,xcoarse,1/10)

# 3.3 By  backward difference method
def Db(f,x,h):
    return (f(x) - f(x - h))/h

d2= Db(fx,xcoarse,1/10)


# 3.4 By central difference method
def Dc(f,x,h):
    return (f(x + h) - f(x - h))/(2*h)

d3 =Dc(fx,xcoarse,1/10)

# plotting the derivatives 
plt.figure(3)
plt.plot ( xsin , df , label ='true reference solution.')
plt.plot(xcoarse,d1, label = 'Forward Difference Method')
plt.plot(xcoarse,d2, label =' Backward difference method')
plt.plot(xcoarse,d3, label = 'Central difference method')
plt.title(" Plot for derivatives")
plt.legend()
plt.show



