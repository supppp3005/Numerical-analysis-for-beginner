

#!/usr/bin/env python3
# -*- coding: utf-8 -*-


import numpy as np
import matplotlib.pyplot as plt
from math import pi


"""
 Lab 6, Part 2- Projection Methods
"""


def ComputeAnalyticalSolution(N,leftbc,rightbc):
   h=(np.pi/2 )/( N+1 )
   x=np.linspace(0 ,(np.pi/2 ),N+2)
   y= 2* np.sin(x) + np.cos(x)
   return x, y


      
      
def ComputeNumericalSolution (N , leftbc , rightbc ):
    h=(np.pi/2 )/( N+1 )
    x=np.linspace(0 ,( np.pi/2 ) ,N+2)
    A=np.zeros (( N , N ) )
    F=np.zeros ( N)
    # Assembly
    A[0 , 0]=-2 +h**2
    A[0, 1] = 1
    
    F[0]=-1
    
    for i in range (1 , N-1):
      A[i , i-1]= 1
      A[i , i]= -2+(h**2)
      A[i , i+1]=1
      F[i]= 0
    A[N-1, N-2]=1
    A[N-1,N-1]=-2+h**2
    F[N-1]=-2
    y_h_int =np.linalg.solve(A , F )
    
    y_h= np.zeros(N+2)
    y_h[0]=1
    y_h[1:N+1] = y_h_int
    y_h[-1]= 2
    return x, y_h ,A

leftbc =1
rightbc =2

# if you want more accurate result change N to big value
# If N = some big number h=small number as h depends on N
N=100

def assemblyf(N, leftbc,rightbc):

   F=np.zeros( N)
   F[0]= leftbc

   for i in range(1,N-1):
      F[i]=0
   
   
   F[N-1]= rightbc
   
   return F

F=assemblyf(100,1,2)


x , y= ComputeAnalyticalSolution (100, leftbc , rightbc )
x_h , y_h , A= ComputeNumericalSolution (N , leftbc , rightbc )

A1=-A


# Q.2

def cg (A ,b , x_cg , maxit ):
   rk = b-np.dot(A,x_cg )
   p = rk
   for k in np.arange ( maxit ):
      alpha = np.dot( rk , rk )/np.dot(p , np.dot(A , p ) )
      x_cg = x_cg + alpha *p
      rkp1 = rk - alpha*np.dot(A,p)
      beta = np.dot(rkp1,rkp1)/np.dot(rk,rk)
      p = rkp1 + beta*p

      rk = rkp1
   return x_cg


x_guess=np.array([1 for i in range(100)])

cg_y= cg(A1,assemblyf(100,1,2),x_guess,100)
x1=np.linspace(0,pi/2,100)



#Plotting for analytic and Numerical soultion
plt.figure(1)
plt.plot (x ,y , Label ='analytical ')
plt.plot ( x1 , cg_y , Label ='numerical')
plt.legend()
plt.title(" Plot Analytical and numerical soultion to BVP:s")
plt.show ()


















