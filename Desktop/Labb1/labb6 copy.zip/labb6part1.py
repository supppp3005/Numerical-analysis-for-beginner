

#!/usr/bin/env python3
# -*- coding: utf-8 -*-


import numpy as np
import matplotlib.pyplot as plt
from math import pi


"""
 Lab 6, Part 1- The Jacobi Method
"""


def ComputeAnalyticalSolution(N,leftbc,rightbc):
   h=(np.pi/2 )/( N+1 )
   x=np.linspace(0 ,(np.pi/2 ),N+2)
   y= 2* np.sin(x) + np.cos(x)
   return x, y
    


# if you want more accurate result change N to big value
# If N = some big number h=small number as h depends on N


x , y= ComputeAnalyticalSolution (100, 1 ,2 )

def assemblyA (N ):
    h=(np.pi/2 )/( N+1 )
    x=np.linspace(0 ,( np.pi/2 ) ,N+2)
    A=np.zeros (( N , N ) )
    
    # Assembly
    A[0 , 0]=-2 +h**2
    A[0, 1] = 1
    
    
    for i in range (1 , N-1):
      A[i , i-1]= 1
      A[i , i]= -2+(h**2)
      A[i , i+1]=1
     
    A[N-1, N-2]=1
    A[N-1,N-1]=-2+h**2
    
    return A
N=5
A= assemblyA(N)


def assemblyf(N, leftbc,rightbc):

   F=np.zeros( N)
   F[0]=- leftbc

   for i in range(1,N-1):
      F[i]=0
   
   
   F[N-1]= -rightbc
   
   return F

F=assemblyf(N,1,2)





def jacobi(A,rightbc,N_it,x):
    
    D = np.diagflat(np.diag(A))
    K = D-A
    D_in= np.linalg.inv(D)
   
    for i in range (N_it):
        fi = np.matmul(D_in,K)
        x  = np.matmul(fi,x)+np.matmul(D_in,rightbc)
    return x



x0=np.array([0,0,0,0,0])
y_k= jacobi(A,F,100,x0)
y_h = np.zeros( N + 2 )
y_h [ 0 ] = 1
y_h [ 1 : N + 1 ] = y_k
y_h [ - 1 ] =  2 


x1 = np.linspace(0 ,( pi / 2 ) ,N +2)


#Plotting for analytic and Numerical soultion
plt.figure(1)
plt.plot (x ,y , Label ='analytical ')
plt.plot ( x1 , y_h , Label ='numerical')
plt.legend()
plt.title(" Plot Analytical and numerical soultion to BVP:s")
#plt.savefig("plot2")
plt.show ()








