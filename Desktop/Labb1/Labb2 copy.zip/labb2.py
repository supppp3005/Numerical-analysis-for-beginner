

# Q.2.A


# Newtons method
# Parameters in function newton
# f: is a function
# Df:is derivative of function
# x0= start value/ initial guess 
# tol = a tolerance 

def newton (f,Df,x0,tol):
    
    x=x0
    
    
    for n in range(100):
        fx=f(x)
        Dfx = Df(x)
        if abs(fx) < tol:
            print('After', n ,'iterations.')
            return x
        
        if Dfx == 0:
            print('Zero derivative. No solution found.')
            return None
        
        x= x-fx/Dfx
        fx=f(x)
        
        
    return x  

# function 
func1 = lambda x: x**3- x- 1
df1= lambda x: 3*x**2-1
x0=1.5# initial value
tol= float(0.001)


f1 = newton(func1,df1,x0,tol)

print("Root of x^3-x-1 is by Newton method with x0=1.5 is x_1:", f1)

# If we test with another intial value
x1=-1.5

f12 = newton(func1,df1,x1,tol)
print("Root of x^3-x-1 is by Newton method with x0=-1.5 is x_2:", f12)



# Q.2.B  
# For another function

func2= lambda x:x**2-1
df2 = lambda x: 2*x

# If we test with another intial value
x21=-1.5

f2= newton(func2,df2,x0,tol)
f21=newton(func2,df2,x21,tol)


print("Root of x^2-1 by Newton method with positive initial value is  :", f2)

print("Root of x^2-1 by Newton method with negative initial value is :", f21)
















