#!/usr/bin/env python3
# -*- coding: utf-8 -*-


import numpy as np
import matplotlib.pyplot as plt
from math import pi


"""
 Lab 5, Part 1- BVP:s and Direct Methods
 Coding Task
"""


def ComputeAnalyticalSolution(N,leftbc,rightbc):
   h=(np.pi/2 )/( N+1 )
   x=np.linspace(0 ,(np.pi/2 ),N+2)
   y= 2* np.sin(x) + np.cos(x)
   return x, y


      
      
def ComputeNumericalSolution (N , leftbc , rightbc ):
    h=(np.pi/2 )/( N+1 )
    x=np.linspace(0 ,( np.pi/2 ) ,N+2)
    A=np.zeros (( N , N ) )
    F=np.zeros ( N)
    # Assembly
    A[0 , 0]=-2 +h**2
    A[0, 1] = 1
    
    F[0]=-1
    
    for i in range (1 , N-1):
      A[i , i-1]= 1
      A[i , i]= -2+(h**2)
      A[i , i+1]=1
      F[i]= 0
    A[N-1, N-2]=1
    A[N-1,N-1]=-2+h**2
    F[N-1]=-2
    y_h_int =np.linalg.solve(A , F )
    
    y_h= np.zeros(N+2)
    y_h[0]=1
    y_h[1:N+1] = y_h_int
    y_h[-1]= 2
    return x, y_h ,A

leftbc =1
rightbc =2

# if you want more accurate result change N to big value
# If N = some big number h=small number as h depends on N
N=3

x , y= ComputeAnalyticalSolution (100, leftbc , rightbc )
x_h , y_h , A= ComputeNumericalSolution (N , leftbc , rightbc )

#Q.2 the the matrix for N = 3

print("Q.2,Matrix A for N=3 ",A)

#Plotting for analytic and Numerical soultion
plt.figure(1)
plt.plot (x ,y , Label ='analytical ')
plt.plot ( x_h , y_h , Label ='numerical N=3')
plt.legend()
plt.title(" Plot Analytical and numerical soultion to BVP:s")
plt.show ()



# Q.4  Truncation error with respect to N

def error(n):
    
    Analytic=[]
    Numerical=[]
    error1=[]
    
    
    for N in range(3,n):
        
        x,y=ComputeAnalyticalSolution(N,1,2)
        Analytic.append(y)
        
   
    
       
        x_h,y_h,A= ComputeNumericalSolution(N,1,2)
        Numerical.append(y_h)
       
       
        error2=y-y_h
        
        epsilon=np.linalg.norm(error2)
        error1.append(epsilon)
       
    return error1

 
# to calculate h for N as array to plot
def h1(n):
   h_e= []
   for j in range(3,n):
       h2=(np.pi/2 )/( j+1 )
       h_e.append(h2)
    
   return h_e

T_error = error(100)
delta_h=h1(100)

#print(delta_h)


# Plotting for error relativ to h
plt.figure(2)
plt.plot (delta_h ,T_error , Label ='Error relative to h ')
plt.xlabel ('h ')
plt.ylabel('Error')
plt.legend()
plt.title(" Plot for error with respect to h")
plt.show ()




'''
Part 3--

'''
from scipy.linalg import norm
import scipy as sp

# Matrix A

A1 = np.array([[10, 7, 8, 7], 
    [7, 5, 6, 5],
    [8, 6, 10, 9],
    [7, 5 , 9 ,10]])

# using scipy for 1 and infinity norm
# print(norm(A1,1))
# print(norm(A1,np.inf ))


# Q.3
#a,
print(np.linalg.cond(A1,2))
#b,
print(np.linalg.norm(A1,2))
#c,
print(sp.linalg.svdvals(A1, 2))
# print the condtion number of matrix A
print(np.linalg.eigvals(A1))


# for the matrix A from ODE-BVP
#plotting for the visualize the sparsity pattern of the matrix A
plt.figure(2)
plt.spy(A)
plt.title(" Plot of sparsity pattern of matrix A.")
plt.show ()
