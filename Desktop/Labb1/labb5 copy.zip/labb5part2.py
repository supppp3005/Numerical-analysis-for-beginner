#!/usr/bin/env python3
# -*- coding: utf-8 -*-


import numpy as np
import matplotlib.pyplot as plt
from math import pi
import scipy


"""
 Lab 5, Part 2- BVP:s and Direct Methods
 Coding Task
"""



# For matrix A

import timeit
starttime = timeit.default_timer ()

def assemblyA (N ):
    h=(np.pi/2 )/( N+1 )
    x=np.linspace(0 ,( np.pi/2 ) ,N+2)
    A=np.zeros (( N , N ) )
    
    # Assembly
    A[0 , 0]=-2 +h**2
    A[0, 1] = 1
    
    
    for i in range (1 , N-1):
      A[i , i-1]= 1
      A[i , i]= -2+(h**2)
      A[i , i+1]=1
     
    A[N-1, N-2]=1
    A[N-1,N-1]=-2+h**2
    
    return A



# if you want more accurate result change N to big value
# If N = some big number h=small number as h depends on N
N=1000

A= assemblyA (N )

leftbc=1
rightbc=2
def assemblyf(N, leftbc,rightbc):

   F=np.zeros( N)
   F[0]= -leftbc

   for i in range(1,N-1):
      F[i]=0
   
   
   F[N-1]= -rightbc
   
   return F

a22= scipy.linalg.lu_factor(assemblyA(N))
def solve(N):
   t=np.linspace(0,1,100)
   yh=np.zeros( N+2)
   for j in t:
       F1 = assemblyf(N,1,2*np.sin(np.pi*j))
       yh = scipy.linalg.lu_solve(a22,F1)
    
   return yh
answer= solve(1000)
endtime = timeit.default_timer()


print (str( endtime - starttime ) )
    
    
    
    
    
    
    
    
    
    
    
    
   