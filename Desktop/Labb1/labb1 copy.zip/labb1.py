
import numpy as np
import scipy
from scipy.integrate import simps



# Part 1
#1. 
#The funcyion we are integrating is

def f1(x):
    return x**3


#Q3.
# A Python function to calculate an integral numerically 
# based on the trapezoidal rule.

# Delta x is given as ∆x = 0.2. We can calculate N by
# N= (b-a)/∆x which gives N=(1-0)/0.2 =5


def trapezoidal(f,xmin,xmax,n):
    h = float(xmax - xmin) / n
    s = 0.0
    s += f(xmin)/2.0
    for i in range(1, n):
        s += f(xmin + i*h)
    s += f(xmax)/2.0
    return s * h


answer_tr = trapezoidal(f1,0,1,5)

print( 'The integral by using trapezoidal rule is :', answer_tr)





# Q5.
# Let try to increase the N to see if we can get 
# the integral value correct in three decimals. is given by N=16 at least

answer_tr2 =trapezoidal(f1,0,1,16)

print("Integral value by using N=16 is:", answer_tr2)



# Q.6 
#Built in numpy function, numpy.trapz, for integrating instead

x= np.array([0,0.2,0.4,0.6,0.8,1])
y= f1(x)


answer_2= np.trapz(y,dx=0.2)
print("Integral value by built in function numpy is :", answer_2)



# Q.7
# By  Using Simpson’s rule  
# with help  of the built-in scipy function 
# midpoint is 0.5 and dx=0.2
N=5; a=0; b=1
x1= np.linspace(a,b,N+1)
answer_3= scipy.integrate.simps(f1(x1),x1)

print("The integral value with Simpson’s rule is:", answer_3)










# Part 2

# 2. Truncation errors

from matplotlib import pyplot as plt

# # 1. For Trapezoidal rule:

# #1.d

# empty list
I_traplist=[]
R_error=[]

# We choose N as [2,5,10,50,100,200]
# Calculte the integral of f(x) in trapezoidal rule as list

for n in [2,5,10,50,100,200]:
    I_trap=trapezoidal(f1,0,1,n)
    I_traplist.append(I_trap)

# Calculate the relative error for every N
for x in I_traplist:
    error =abs((0.25-x)/0.25)
    R_error.append(error)
        
# x-axis is ∆x=(b-a)/N, as we are using different N
dx=[0.5,0.2,0.1,0.02,0.01,0.005]


# y-axis as Relative error
y=R_error


# plotting x and y 
plt.plot(dx, y)
plt.xlabel(' ∆x')
plt.ylabel('Relativ error')
plt.title('T_Relative error against ∆x')
plt.show()

# #1.e
## By using log − log axis. matplotlib function
plt.loglog(dx, y)
plt.xlabel(' ∆x')
plt.ylabel('Relativ error')
plt.title('T_Relative error against ∆x with loglog function')
plt.show()


# # 1. for The order of Trapezodial method
p = np.polyfit(np.log(dx),np.log(y),1)
print('The order of the trapezoidal method is:',p[0])






# # 2. Simpson’s rule:
    
# the function we are integrating
def f2(x):
    return x**4


# Integrating by using simson*s rule for different N
# We are using the function f2(x)=x^4

# we gonna use N=[2,5,10,50,100,200]
# Between intervals [0,1] and , ∆x=0.5
x_2= np.linspace(0,1,3)
I_s = scipy.integrate.simps(f2(x_2),x_2)

# For ∆x=0.2 we have
x3 = np.linspace(0,1,6)
I_s2=I_s = scipy.integrate.simps(f2(x3),x3)

# For ∆x=0.1 we have
x4= np.linspace(0,1,11)
I_s3=I_s = scipy.integrate.simps(f2(x4),x4)

# For For ∆x=0.02
x5=np.linspace(0,1,51)
I_s4=I_s = scipy.integrate.simps(f2(x5),x5)


#For ∆x=0.01
x6=np.linspace(0,1,101)
I_s5 = scipy.integrate.simps(f2(x6),x6)


# For ∆x=0.005
x7=np.linspace(0,1,201)
I_s6 = scipy.integrate.simps(f2(x7),x7)

# for delta x = 0.001
x8= np.linspace(0,1,1000)
I_s7= scipy.integrate.simps(f2(x8),x8)

# for delta x = 0.0001
x9= np.linspace(0,1,10000)
I_s8= scipy.integrate.simps(f2(x9),x9)

# for delta x = 0.00001
x10= np.linspace(0,1,100000)
I_s9= scipy.integrate.simps(f2(x10),x10)

# for delta x = 0.00001
x11= np.linspace(0,1,1000000)
I_s10= scipy.integrate.simps(f2(x11),x11)



# Now in order to plot relative error we start by creating
# Empty list as
# the exakt integral value of f(x) =x^4 is 0.2

## Then Relativ errors of different N
Rs_error=[]
I_ss=[I_s,I_s2,I_s3,I_s4,I_s5,I_s6,I_s7,I_s8,I_s9,I_s10]
for x in I_ss:
    error1 =abs((0.20-x)/0.20)
    Rs_error.append(error1)


# Different intervalls n, different ∆x

deltax=[0.5,0.2,0.1,0.02,0.01,0.005,0.001,0.0001,0.00001,0.000001]


## with log − log axis. matplotlib for simsons error against ∆x.
plt.loglog(deltax, Rs_error)
plt.xlabel(' ∆x')
plt.ylabel('Relativ error')
plt.title('Simpson_Relative error against ∆x with loglog function')
plt.show()


# order of simson rule


p = np.polyfit(np.log(deltax),np.log(Rs_error),1)
print('The order of the simpson method is:',p[0])




















