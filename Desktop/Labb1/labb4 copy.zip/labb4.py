#!/usr/bin/env python3
# -*- coding: utf-8 -*-

'''
 
 Labb 4- Part 1: Euler methods
  
'''

import matplotlib . pyplot as plt
import numpy as np



# Q.1 and Q.2 Forward Euler until time T

t=0 # initial time
T=10 # end time

y0= 1 # intial condition



# function f(t,y)
def func(t , y):
    return -float(0.5)*y



ynew =y0 # setting y_i to initial value


# creating empty lists which will be used for the plot
yvec =[]
yvec.append (ynew )


timevec =[]
timevec.append (t )


h=1# timestep

# Forward Euler formula

while t < T: # loop over time

   
    ycurrent = ynew
    ynew =  ycurrent + h * func(t,ycurrent)
   
    t=t+h
  
    timevec.append(t )# adding t_i to a vector ( list ) for the plot
    yvec.append(ynew)
    

    

# For the analytical solution
dt=0.1
t1=0 # initial time

yanalytic =[]
yanalytic.append(y0 )

timevec1 =[]
timevec1.append (t1 )

while t1 < T:
    
    t1=t1+dt
    
    analyticalsolution =np.exp(-float(0.5)*t1)
    
    timevec1.append(t1 )
    yanalytic.append(analyticalsolution)
    
    
    





# Q.3 Backward Euler

" For this function i have calculated the "
"yn+1 interms of yn of function, see part 1 .pdf file"
def backward_eular(f,y_0,T1,h1):
    # f is f(t,y)
    # y_0 = intial value
    # T1 = array(0,10) 
    # h1= Step size
    
    n=int((T1[-1] - T1[0])/h1)
    t2 = T1[0]
    y1 = y_0
    t_out, y_out = np.array([t2]), np.array([y1])
    for i in range(n):
        y2 = f(t2,y1)/(1 + h1 * float(0.5))
        y1 += h1 * y2
        t2 += h1
        t_out = np.append(t_out, t2)
        y_out = np.append(y_out, y1)

    return t_out, y_out

" backwardeular returns array for t and y"

t5,y5= backward_eular(func,1,(0,10),1)







'''
 
 Labb 4- Part 2: Euler methods
  
'''


# Q.1  Second order Runge-Kutta method(RK2)



def RK2 (f,y00,T2,h2):
    # f is f(t,y)
    # y_00 = intial value
    # T2= array(0,T) 
    # h1= Step size
    
    n=int((T2[-1] - T2[0])/h2)
    t4 = T2[0]
    y4 = y00
    t_out1, y_out1 = np.array([t4]), np.array(y4)
    for i in range(n):

        k1 =h* f(t4, y4)
        k2 = f(t4 + 0.5*h2, y4 + 0.5*k1*h2)
        y4 += k2*h2
        t4 += h2
        
        t_out1 = np.append(t_out1, t4)
        y_out1 = np.append(y_out1, y4)
    return t_out1,y_out1


tvector,yvector= RK2(func,1,(0,10),1)


#plotting as h=1
plt.plot(tvector,yvector, label = 'RK2')
plt.plot( timevec ,yvec , label = ' Forward eular h=')
plt.plot(t5,y5, label = 'Backward eular')
plt.plot( timevec1 , yanalytic , label = 'analytical solution ')
plt.xlabel ('time ')
plt.legend ()
plt.title("Plot using h=1 for Euler methods and RK2")
plt.show ()








